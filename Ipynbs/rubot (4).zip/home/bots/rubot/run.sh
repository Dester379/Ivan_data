
/usr/bin/python3 chatbot_end.py
